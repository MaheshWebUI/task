document.getElementById("hide").onclick = function() {
    document.getElementById("full-image-width-close").style.display = "none";
}
$('#Live_Score').click(function(e){
    e.preventDefault();
    $.ajax({
        type: "POST",
        url: "live_score.html",
        data: { },
        success: function(data){
            $('#maincont1').html(data);
        }
    });
});

$('#Corona_Cases').click(function(e){
    e.preventDefault();
    $.ajax({
        type: "POST",
        url: "corona_cases.html",
        data: { },
        success: function(data){
            $('#maincont2').html(data);
        }
    });
});

$('#Olympics_India').click(function(e){
    e.preventDefault();
    $.ajax({
        type: "POST",
        url: "olympics_india.html",
        data: { },
        success: function(data){
            $('#maincont3').html(data);
        }
    });
});